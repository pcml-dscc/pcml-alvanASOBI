# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP02 — Assessment Task 2: Hypothesis Testing, Bootstrap & CUPED

Complete the `solve()` function. Read problem.md for the full specification.
The bootstrap is auto-graded against a bit-reproducible reference: you MUST
follow the seed / resample protocol exactly (treatment resampled before
control, every iteration).

    python grader.py starter.py
"""
from __future__ import annotations

import numpy as np
import polars as pl
from scipy import stats

from shared import MLFPDataLoader

# --- Fixed problem constants (do not change) ---
COHORT = ["control", "treatment_a"]
BOOT_SEED = 2024            # np.random.default_rng(BOOT_SEED)
BOOT_B = 2000              # number of bootstrap resamples
MT_P_VALUES = [0.03, 0.012, 0.04, 0.65, 0.009]   # five simultaneous tests
MT_ALPHA = 0.05


def solve() -> dict:
    """Return the hypothesis-testing / bootstrap / CUPED answer dict."""
    loader = MLFPDataLoader()
    df = loader.load("mlfp02", "experiment_data.parquet")
    co = df.filter(pl.col("experiment_group").is_in(COHORT))

    # --- TODO 1: Welch t-test (treatment_a vs control), file order --------
    t = (
        co.filter(pl.col("experiment_group") == "treatment_a")
        .get_column("metric_value")
        .to_numpy()
        .astype(float)
    )
    c = (
        co.filter(pl.col("experiment_group") == "control")
        .get_column("metric_value")
        .to_numpy()
        .astype(float)
    )
    welch_t, welch_p = stats.ttest_ind(t, c, equal_var=False)
    mean_diff = t.mean() - c.mean()

    # --- TODO 2: seeded percentile bootstrap (EXACT protocol) -------------
    rng = np.random.default_rng(BOOT_SEED)
    diffs = np.empty(BOOT_B)
    for b in range(BOOT_B):
        bt = rng.choice(t, size=t.size, replace=True)   # treatment FIRST
        bc = rng.choice(c, size=c.size, replace=True)   # control SECOND
        diffs[b] = bt.mean() - bc.mean()
    boot_ci_low, boot_ci_high = np.percentile(diffs, [2.5, 97.5])

    # --- TODO 3: CUPED over the full cohort -------------------------------
    metric = co.get_column("metric_value").to_numpy().astype(float)
    pre = co.get_column("pre_metric_value").to_numpy().astype(float)
    cuped_theta = np.cov(metric, pre, ddof=1)[0, 1] / np.var(pre, ddof=1)
    metric_adj = metric - cuped_theta * (pre - pre.mean())
    var_metric = np.var(metric, ddof=1)
    var_adj = np.var(metric_adj, ddof=1)
    cuped_var_reduction = 1.0 - var_adj / var_metric

    # --- TODO 4: CUPED-adjusted Welch test --------------------------------
    groups = co.get_column("experiment_group").to_numpy()
    t_adj = metric_adj[groups == "treatment_a"]
    c_adj = metric_adj[groups == "control"]
    welch_t_cuped, welch_p_cuped = stats.ttest_ind(t_adj, c_adj, equal_var=False)

    # --- TODO 5: multiple-testing correction ------------------------------
    m = len(MT_P_VALUES)
    alpha = MT_ALPHA
    bonferroni_n_sig = int(sum(pv < alpha / m for pv in MT_P_VALUES))

    sorted_p = sorted(MT_P_VALUES)
    bh_n_sig = 0
    for i, pv in enumerate(sorted_p, start=1):
        if pv <= alpha * i / m:
            bh_n_sig = i   # largest rank meeting the BH threshold
    bh_n_sig = int(bh_n_sig)

    # --- TODO 6: return contract (13 keys) --------------------------------
    return {
        "welch_t": float(welch_t),
        "welch_p": float(welch_p),
        "mean_diff": float(mean_diff),
        "boot_ci_low": float(boot_ci_low),
        "boot_ci_high": float(boot_ci_high),
        "cuped_theta": float(cuped_theta),
        "var_metric": float(var_metric),
        "var_adj": float(var_adj),
        "cuped_var_reduction": float(cuped_var_reduction),
        "welch_t_cuped": float(welch_t_cuped),
        "welch_p_cuped": float(welch_p_cuped),
        "bonferroni_n_sig": int(bonferroni_n_sig),
        "bh_n_sig": int(bh_n_sig),
    }


if __name__ == "__main__":
    print(solve())
