# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP02 — Assessment Task 4: Feature Engineering & Feature Store

Complete the `solve()` function. Read problem.md for the full specification.
You join five raw ICU tables into one admission-level feature table. The event
tables are messy: lab values contain junk strings, doses are like "34.8MG", and
many admissions have no vitals/labs at all. Your output is auto-graded
column-by-column against an independent re-derivation.

    python grader.py starter.py
"""
from __future__ import annotations

import polars as pl

from shared import MLFPDataLoader

DT_FMT = "%Y-%m-%d %H:%M:%S"

FEATURE_COLUMNS = [
    "admission_id",
    "feature_timestamp",
    "age",
    "gender",
    "bmi",
    "diagnosis",
    "icu_type",
    "mean_heart_rate",
    "mean_systolic_bp",
    "min_spo2",
    "max_temperature",
    "n_vitals",
    "n_labs",
    "n_abnormal_labs",
    "mean_creatinine",
    "n_distinct_drugs",
    "n_iv_meds",
    "total_dose_mg",
    "los_days",
]

# Columns imputed with their own median (Float64).
MEDIAN_COLS = [
    "age",
    "bmi",
    "mean_heart_rate",
    "mean_systolic_bp",
    "min_spo2",
    "max_temperature",
    "mean_creatinine",
]
# Count columns imputed with 0 (Int64).
COUNT_COLS = [
    "n_vitals",
    "n_labs",
    "n_abnormal_labs",
    "n_distinct_drugs",
    "n_iv_meds",
]


def solve() -> pl.DataFrame:
    """Build the 19-column admission-level feature-store table."""
    loader = MLFPDataLoader()
    adm = loader.load("mlfp02", "icu_admissions.parquet")
    pat = loader.load("mlfp02", "icu_patients.parquet")
    vit = loader.load("mlfp02", "icu_vitals.parquet")
    labs = loader.load("mlfp02", "icu_labs.parquet")
    meds = loader.load("mlfp02", "icu_medications.parquet")

    # --- TODO 1: base + anchor + demographics -----------------------------
    base = adm.select(
        "admission_id",
        "patient_id",
        "diagnosis",
        "icu_type",
        "los_days",
        pl.col("admit_time")
        .str.strptime(pl.Datetime, DT_FMT)
        .alias("feature_timestamp"),
    ).join(
        pat.select("patient_id", "age", "gender", "bmi"),
        on="patient_id",
        how="left",
    )

    # --- TODO 2: vitals aggregates ----------------------------------------
    vit_agg = vit.group_by("admission_id").agg(
        pl.col("heart_rate").mean().alias("mean_heart_rate"),
        pl.col("systolic_bp").mean().alias("mean_systolic_bp"),
        pl.col("spo2").min().alias("min_spo2"),
        pl.col("temperature").max().alias("max_temperature"),
        pl.len().alias("n_vitals"),
    )

    # --- TODO 3: labs (parse value, lowercase flag) -----------------------
    labs_parsed = labs.with_columns(
        pl.col("value").cast(pl.Float64, strict=False).alias("value_num"),
        pl.col("flag").str.to_lowercase().alias("flag_lc"),
    )
    labs_agg = labs_parsed.group_by("admission_id").agg(
        pl.len().alias("n_labs"),
        (pl.col("flag_lc") == "abnormal").sum().alias("n_abnormal_labs"),
        pl.col("value_num")
        .filter(pl.col("test_name") == "Creatinine")
        .mean()
        .alias("mean_creatinine"),
    )

    # --- TODO 4: medications (parse leading numeric dose) -----------------
    meds_parsed = meds.with_columns(
        pl.col("dose")
        .str.extract(r"([0-9]+\.?[0-9]*)", 1)
        .cast(pl.Float64, strict=False)
        .alias("dose_mg")
    )
    meds_agg = meds_parsed.group_by("admission_id").agg(
        pl.col("drug_name").n_unique().alias("n_distinct_drugs"),
        (pl.col("route") == "IV").sum().alias("n_iv_meds"),
        pl.col("dose_mg").sum().alias("total_dose_mg"),
    )

    # --- TODO 5: left-join the aggregate blocks onto the base -------------
    out = (
        base.join(vit_agg, on="admission_id", how="left")
        .join(labs_agg, on="admission_id", how="left")
        .join(meds_agg, on="admission_id", how="left")
    )

    # --- TODO 6: imputation policy (medians computed BEFORE filling) ------
    medians = {c: out.get_column(c).median() for c in MEDIAN_COLS}

    out = out.with_columns(
        pl.col("gender").fill_null("Unknown"),
        pl.col("total_dose_mg").fill_null(0.0).cast(pl.Float64),
        *[pl.col(c).fill_null(0).cast(pl.Int64) for c in COUNT_COLS],
        *[
            pl.col(c).fill_null(medians[c]).cast(pl.Float64)
            for c in MEDIAN_COLS
        ],
    )

    # --- TODO 7: select in order, sort by admission_id --------------------
    return out.select(FEATURE_COLUMNS).sort("admission_id")


if __name__ == "__main__":
    print(solve().head())
