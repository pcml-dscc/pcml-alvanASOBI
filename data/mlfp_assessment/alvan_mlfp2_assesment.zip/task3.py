# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP02 — Assessment Task 3: Regression Modelling & Interpretation

Complete the `solve()` function. Read problem.md for the full specification.
Every regression is solved in closed form (OLS via least squares; logistic via
Newton-Raphson to the unique MLE) so your numbers must match the independently
re-derived reference. Standardise predictors (z-score) before fitting.

    python grader.py starter.py
"""
from __future__ import annotations

import numpy as np
import polars as pl
from scipy import stats

from shared import MLFPDataLoader

# --- Fixed problem constants (do not change) ---
OLS_FEATURES = [
    "income_imp",
    "age",
    "employment_years",
    "debt_to_income",
    "credit_age_years",
    "num_dependents",
    "edu_ord",
]
LOGIT_FEATURES = [
    "credit_utilization",
    "num_late_payments",
    "previous_defaults",
    "debt_to_income",
    "num_hard_inquiries",
]
EDU_MAP = {
    "primary": 1.0,
    "secondary": 2.0,
    "diploma": 3.0,
    "degree": 4.0,
    "postgraduate": 5.0,
}
TARGET = "loan_amount_sgd"


def _zscore(M: np.ndarray) -> np.ndarray:
    """Column-wise z-score with population sd (ddof=0)."""
    mu = M.mean(axis=0)
    sd = M.std(axis=0, ddof=0)
    return (M - mu) / sd


def solve() -> dict:
    """Return the regression / interpretation answer dict."""
    loader = MLFPDataLoader()
    df = loader.load("mlfp02", "sg_credit_scoring.parquet")

    # --- TODO 1: preprocessing (no rows dropped) --------------------------
    income_median = df.select(pl.col("income_sgd").median()).item()
    df = df.with_columns(
        pl.col("income_sgd").fill_null(income_median).alias("income_imp"),
        pl.col("education")
        .replace_strict(EDU_MAP, return_dtype=pl.Float64)
        .alias("edu_ord"),
    )
    n_obs = df.height
    n = n_obs

    # --- TODO 2: OLS design — standardise predictors, raw target ----------
    X_raw = df.select(OLS_FEATURES).to_numpy().astype(float)
    y = df.get_column(TARGET).to_numpy().astype(float)

    X_std = _zscore(X_raw)
    X = np.column_stack([np.ones(n), X_std])
    p = X.shape[1]                      # intercept + 7 features

    beta, *_ = np.linalg.lstsq(X, y, rcond=None)

    # --- TODO 3: inference -------------------------------------------------
    resid = y - X @ beta
    rss = float(resid @ resid)
    tss = float(((y - y.mean()) ** 2).sum())
    r_squared = 1.0 - rss / tss
    adj_r_squared = 1.0 - (1.0 - r_squared) * (n - 1) / (n - p)

    sigma2 = rss / (n - p)
    XtX_inv = np.linalg.inv(X.T @ X)
    se = np.sqrt(np.diag(sigma2 * XtX_inv))
    t_vals = beta / se
    p_vals = 2.0 * stats.t.sf(np.abs(t_vals), df=n - p)

    f_statistic = (r_squared / (p - 1)) / ((1.0 - r_squared) / (n - p))
    f_p_value = float(stats.f.sf(f_statistic, p - 1, n - p))

    names = ["intercept"] + OLS_FEATURES
    coefficients = {nm: float(b) for nm, b in zip(names, beta)}
    t_stats = {nm: float(tt) for nm, tt in zip(names, t_vals)}
    p_values = {nm: float(pp) for nm, pp in zip(names, p_vals)}

    # --- TODO 4: partial F-test (two terms from standardised cols) --------
    income_std = X_std[:, OLS_FEATURES.index("income_imp")]
    age_std = X_std[:, OLS_FEATURES.index("age")]
    emp_std = X_std[:, OLS_FEATURES.index("employment_years")]
    extra = np.column_stack([income_std ** 2, age_std * emp_std])

    X_full = np.column_stack([X, extra])
    p_full = X_full.shape[1]
    beta_full, *_ = np.linalg.lstsq(X_full, y, rcond=None)
    resid_full = y - X_full @ beta_full
    rss_full = float(resid_full @ resid_full)
    r2_full = 1.0 - rss_full / tss

    q = 2
    partial_f = ((rss - rss_full) / q) / (rss_full / (n - p_full))
    partial_f_p_value = float(stats.f.sf(partial_f, q, n - p_full))
    delta_r_squared = r2_full - r_squared

    # --- TODO 5: logistic regression via Newton-Raphson / IRLS ------------
    Xl_raw = df.select(LOGIT_FEATURES).to_numpy().astype(float)
    yl = df.get_column("default").to_numpy().astype(float)
    Xl = np.column_stack([np.ones(n), _zscore(Xl_raw)])

    beta_l = np.zeros(Xl.shape[1])
    for _ in range(100):
        eta = Xl @ beta_l
        mu = 1.0 / (1.0 + np.exp(-eta))
        W = np.clip(mu * (1.0 - mu), 1e-12, None)
        grad = Xl.T @ (yl - mu)
        H = Xl.T @ (Xl * W[:, None])
        delta = np.linalg.solve(H, grad)
        beta_l = beta_l + delta
        if np.max(np.abs(delta)) < 1e-10:
            break

    logit_names = ["intercept"] + LOGIT_FEATURES
    odds_ratios = {nm: float(np.exp(b)) for nm, b in zip(logit_names, beta_l)}
    # strongest predictor excluding the intercept
    abs_betas = {nm: abs(b) for nm, b in zip(LOGIT_FEATURES, beta_l[1:])}
    strongest_logit_predictor = max(abs_betas, key=abs_betas.get)

    # --- TODO 6: return contract (13 keys) --------------------------------
    return {
        "n_obs": int(n_obs),
        "coefficients": coefficients,
        "t_stats": t_stats,
        "p_values": p_values,
        "r_squared": float(r_squared),
        "adj_r_squared": float(adj_r_squared),
        "f_statistic": float(f_statistic),
        "f_p_value": float(f_p_value),
        "partial_f": float(partial_f),
        "partial_f_p_value": float(partial_f_p_value),
        "delta_r_squared": float(delta_r_squared),
        "odds_ratios": odds_ratios,
        "strongest_logit_predictor": str(strongest_logit_predictor),
    }


if __name__ == "__main__":
    print(solve())
