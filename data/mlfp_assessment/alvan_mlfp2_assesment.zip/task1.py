# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP02 — Assessment Task 1: Probability, Bayes & Experiment Validation

Complete the `solve()` function. Read problem.md for the full specification.
Your submission is auto-graded: every probability, the SRM chi-square, the
base-rate Bayes scalar, and the Beta posterior must match the independently
re-derived reference within tight tolerances.

    python grader.py starter.py
"""
from __future__ import annotations

import polars as pl
from scipy import stats

from shared import MLFPDataLoader

# --- Fixed problem constants (do not change) ---
COHORT = ["control", "treatment_a"]
CONVERT_THRESHOLD = 50.0          # converted := metric_value >= 50.0
FRAUD_BASE_RATE = 0.02            # P(fraud)
FRAUD_SENSITIVITY = 0.95          # P(flagged | fraud)
FRAUD_FPR = 0.03                  # P(flagged | not fraud)
BETA_PRIOR_ALPHA = 2.0
BETA_PRIOR_BETA = 20.0


def solve() -> dict:
    """Return the probability / Bayes / experiment-validation answer dict."""
    loader = MLFPDataLoader()
    df = loader.load("mlfp02", "experiment_data.parquet")

    # --- TODO 1: cohort + converted flag ----------------------------------
    co = df.filter(pl.col("experiment_group").is_in(COHORT)).with_columns(
        (pl.col("metric_value") >= CONVERT_THRESHOLD).alias("converted")
    )

    control = co.filter(pl.col("experiment_group") == "control")
    treatment = co.filter(pl.col("experiment_group") == "treatment_a")

    n_total = co.height
    n_control = control.height
    n_treatment = treatment.height

    # --- TODO 2: conditional probabilities --------------------------------
    p_convert_overall = co.select(pl.col("converted").mean()).item()
    p_convert_control = control.select(pl.col("converted").mean()).item()
    p_convert_treatment = treatment.select(pl.col("converted").mean()).item()

    # --- TODO 3: Bayes inversion ------------------------------------------
    # P(treatment_a) is treatment_a's share of the cohort (not the full file).
    p_treatment = n_treatment / n_total
    p_treatment_given_convert = (
        p_convert_treatment * p_treatment / p_convert_overall
    )

    # --- TODO 4: Sample Ratio Mismatch (chi-square goodness-of-fit) --------
    expected = n_total / 2.0
    srm_chi2 = (
        (n_control - expected) ** 2 / expected
        + (n_treatment - expected) ** 2 / expected
    )
    srm_p_value = float(stats.chi2.sf(srm_chi2, df=1))
    srm_flag = bool(srm_p_value < 1e-3)

    # --- TODO 5: fraud base-rate Bayes (scalar) ---------------------------
    sens, base, fpr = FRAUD_SENSITIVITY, FRAUD_BASE_RATE, FRAUD_FPR
    p_fraud_given_flagged = sens * base / (sens * base + fpr * (1.0 - base))

    # --- TODO 6: Beta-Binomial conjugate update on treatment_a ------------
    successes = int(treatment.select(pl.col("converted").sum()).item())
    failures = n_treatment - successes
    beta_post_alpha = BETA_PRIOR_ALPHA + successes
    beta_post_beta = BETA_PRIOR_BETA + failures
    posterior_mean = beta_post_alpha / (beta_post_alpha + beta_post_beta)
    cred_int_low = float(stats.beta.ppf(0.025, beta_post_alpha, beta_post_beta))
    cred_int_high = float(stats.beta.ppf(0.975, beta_post_alpha, beta_post_beta))

    # --- TODO 7: return contract (13 keys) --------------------------------
    return {
        "p_convert_overall": float(p_convert_overall),
        "p_convert_control": float(p_convert_control),
        "p_convert_treatment": float(p_convert_treatment),
        "p_treatment_given_convert": float(p_treatment_given_convert),
        "srm_chi2": float(srm_chi2),
        "srm_p_value": float(srm_p_value),
        "srm_flag": bool(srm_flag),
        "p_fraud_given_flagged": float(p_fraud_given_flagged),
        "beta_post_alpha": float(beta_post_alpha),
        "beta_post_beta": float(beta_post_beta),
        "posterior_mean": float(posterior_mean),
        "cred_int_low": float(cred_int_low),
        "cred_int_high": float(cred_int_high),
    }


if __name__ == "__main__":
    print(solve())
