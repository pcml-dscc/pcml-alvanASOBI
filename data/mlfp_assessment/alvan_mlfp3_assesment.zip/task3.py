# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP03 — Assessment Task 3: Evaluation, Class Imbalance & Interpretability

Complete the `solve()` function. Read problem.md for the full specification.
Train a baseline and a class-balanced RandomForest through the kailash-ml
`TrainingPipeline`, evaluate per-class behaviour with `km.diagnose`, and explain
the balanced model with `ModelExplainer` (SHAP). Your submission is auto-graded
against an independent re-derivation.

    python grader.py task3.py     # grade your attempt
"""
from __future__ import annotations

import asyncio
import pickle
import warnings

import numpy as np
import polars as pl

from shared import MLFPDataLoader

import kailash_ml as km
from kailash.db.connection import ConnectionManager
from kailash_ml.engines.model_registry import ModelRegistry
from kailash_ml.engines.model_explainer import ModelExplainer
from kailash_ml.engines.training_pipeline import EvalSpec, ModelSpec, TrainingPipeline
from kailash_ml.interop import to_sklearn_input
from kailash_ml.types import FeatureField, FeatureSchema

warnings.filterwarnings("ignore")

N_ROWS = 10_000
SEED = 42
TARGET = "premium_response"
TOP_K = 6
SHAP_BACKGROUND = 64
BASE_FEATURES = [
    "satisfaction_score",
    "avg_order_value",
    "num_returns",
    "order_count",
    "loyalty_int",
    "total_revenue",
    "days_since_last_order",
    "customer_tenure_days",
]


def _model_frame() -> pl.DataFrame:
    """Load N_ROWS, derive ``premium_response`` (given), return the model frame."""
    df = MLFPDataLoader().load("mlfp03", "ecommerce_customers.parquet")
    df = df.sort("customer_id").head(N_ROWS)
    rng = np.random.default_rng(SEED)

    def z(col: str) -> np.ndarray:
        a = df[col].to_numpy().astype(float)
        return (a - a.mean()) / (a.std() + 1e-9)

    loyal = df["loyalty_member"].cast(pl.Int64).to_numpy().astype(float)
    sat_high = (df["satisfaction_score"] >= 4).cast(pl.Int64).to_numpy().astype(float)
    logit = (
        1.0 * z("satisfaction_score")
        + 0.9 * loyal
        + 0.8 * z("avg_order_value")
        - 0.7 * z("num_returns")
        + 0.5 * z("order_count")
        + 1.4 * (loyal * sat_high)
        + rng.normal(0.0, 1.3, size=df.height)
    )
    df = df.with_columns(
        [
            pl.col("loyalty_member").cast(pl.Int64).alias("loyalty_int"),
            pl.Series(TARGET, (logit > 2.0).astype(np.int64)),
            pl.int_range(0, df.height, dtype=pl.Int64).alias("row_id"),
        ]
    )
    return df.select(BASE_FEATURES + ["row_id", TARGET])


def _holdout_test(frame: pl.DataFrame) -> pl.DataFrame:
    """Reproduce TrainingPipeline's deterministic holdout split (test portion).

    Use this same X_test / y_test for km.diagnose so per-class recall lines up
    with the engine's evaluation. Given to you — do not change.
    """
    n = frame.height
    idx = np.arange(n)
    np.random.RandomState(42).shuffle(idx)
    split_idx = int(n * 0.75)
    return frame[idx[split_idx:].tolist()]


_DTYPE_MAP = {
    pl.Int64: "int64",
    pl.Float64: "float64",
}


def _build_schema(df: pl.DataFrame) -> FeatureSchema:
    features = [
        FeatureField(
            name=col,
            dtype=_DTYPE_MAP.get(df[col].dtype, "float64"),
            nullable=False,
        )
        for col in BASE_FEATURES
    ]
    return FeatureSchema(
        name="premium_upsell_imbalance",
        features=features,
        entity_id_column="row_id",
    )


async def _run() -> dict:
    frame = _model_frame()
    schema = _build_schema(frame)
    eval_spec = EvalSpec(
        metrics=["accuracy", "f1", "auc"],
        split_strategy="holdout",
        test_size=0.25,
    )

    conn = ConnectionManager("sqlite:///:memory:")
    await conn.initialize()
    try:
        registry = ModelRegistry(conn)
        pipeline = TrainingPipeline(feature_store=None, registry=registry)

        # TODO 2: train the baseline and class-balanced RandomForests.
        baseline_spec = ModelSpec(
            model_class="sklearn.ensemble.RandomForestClassifier",
            hyperparameters={"n_estimators": 150, "random_state": SEED, "n_jobs": -1},
            framework="sklearn",
        )
        balanced_spec = ModelSpec(
            model_class="sklearn.ensemble.RandomForestClassifier",
            hyperparameters={
                "n_estimators": 150,
                "random_state": SEED,
                "n_jobs": -1,
                "class_weight": "balanced",
            },
            framework="sklearn",
        )

        baseline_result = await pipeline.train(
            frame, schema, baseline_spec, eval_spec, experiment_name="baseline_rf"
        )
        balanced_result = await pipeline.train(
            frame, schema, balanced_spec, eval_spec, experiment_name="balanced_rf"
        )

        # TODO 3: load both fitted models back from the registry.
        baseline_model = pickle.loads(
            await registry.load_artifact(
                baseline_result.model_version.name,
                baseline_result.model_version.version,
            )
        )
        balanced_model = pickle.loads(
            await registry.load_artifact(
                balanced_result.model_version.name,
                balanced_result.model_version.version,
            )
        )

        # TODO 4: per-class evaluation with km.diagnose on the SAME holdout
        # test split the engine used internally.
        test_frame = _holdout_test(frame)
        X_test, y_test, _ = to_sklearn_input(
            test_frame, feature_columns=BASE_FEATURES, target_column=TARGET
        )

        baseline_report = km.diagnose(
            baseline_model,
            kind="classical_classifier",
            data=(X_test, y_test),
            show=False,
        )
        balanced_report = km.diagnose(
            balanced_model,
            kind="classical_classifier",
            data=(X_test, y_test),
            show=False,
        )

        # TODO 5: interpret the BALANCED model with SHAP.
        explainer = ModelExplainer(
            model=balanced_model,
            X=frame.select(BASE_FEATURES).head(SHAP_BACKGROUND),
            feature_names=BASE_FEATURES,
        )
        feature_importance = explainer.explain_global(max_display=TOP_K)[
            "feature_importance"
        ]
        top_features = list(feature_importance.keys())[:TOP_K]

        return {
            "baseline_minority_recall": baseline_report.per_class["1.0"]["recall"],
            "balanced_minority_recall": balanced_report.per_class["1.0"]["recall"],
            "baseline_recall_macro": baseline_report.metrics["recall_macro"],
            "balanced_recall_macro": balanced_report.metrics["recall_macro"],
            "baseline_accuracy": baseline_report.metrics["accuracy"],
            "balanced_accuracy": balanced_report.metrics["accuracy"],
            "roc_auc": balanced_result.metrics["auc"],
            "top_features": top_features,
            "n_features": len(BASE_FEATURES),
        }
    finally:
        await conn.close()


def solve() -> dict:
    """Evaluate imbalance handling + interpret the balanced model.

    Return a dict with: baseline_minority_recall, balanced_minority_recall,
    baseline_recall_macro, balanced_recall_macro, baseline_accuracy,
    balanced_accuracy, roc_auc, top_features (top-6 by SHAP), n_features.
    """
    return asyncio.run(_run())


if __name__ == "__main__":
    print(solve())
