# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP03 — Assessment Task 4: Production Pipeline — Registry, Drift, Deploy

Complete the `solve()` function. Read problem.md for the full specification.
Train a LightGBM model through the kailash-ml `TrainingPipeline`, register and
promote it staging -> production in the `ModelRegistry`, then arm a
`DriftMonitor` and check a clean slice (no alarm) and a shifted slice (drift).
Your submission is auto-graded against an independent re-derivation.

    python grader.py task4.py     # grade your attempt

IMPORTANT — TWO DATABASES: give the ModelRegistry and the DriftMonitor SEPARATE
SQLite files. A model registry and a monitoring store are distinct systems with
independent lifecycles, and using fresh, separate files avoids reusing a stale
database whose schema predates your installed kailash-ml version.
"""
from __future__ import annotations

import asyncio
import os
import tempfile
import uuid
import warnings
from pathlib import Path

import numpy as np
import polars as pl

from shared import MLFPDataLoader

from kailash.db.connection import ConnectionManager
from kailash_ml.engines.drift_monitor import DriftMonitor
from kailash_ml.engines.model_registry import ModelRegistry
from kailash_ml.engines.training_pipeline import EvalSpec, ModelSpec, TrainingPipeline
from kailash_ml.types import FeatureField, FeatureSchema

warnings.filterwarnings("ignore")

N_ROWS = 10_000
SEED = 42
TARGET = "premium_response"
REFERENCE_ROWS = 7_500
PSI_THRESHOLD = 0.2
KS_THRESHOLD = 0.05
MODEL_NAME = "premium_upsell_lgbm"
BASE_FEATURES = [
    "satisfaction_score",
    "avg_order_value",
    "num_returns",
    "order_count",
    "loyalty_int",
    "total_revenue",
    "days_since_last_order",
    "customer_tenure_days",
]


def _model_frame() -> pl.DataFrame:
    """Load N_ROWS, derive ``premium_response`` (given), return the model frame."""
    df = MLFPDataLoader().load("mlfp03", "ecommerce_customers.parquet")
    df = df.sort("customer_id").head(N_ROWS)
    rng = np.random.default_rng(SEED)

    def z(col: str) -> np.ndarray:
        a = df[col].to_numpy().astype(float)
        return (a - a.mean()) / (a.std() + 1e-9)

    loyal = df["loyalty_member"].cast(pl.Int64).to_numpy().astype(float)
    sat_high = (df["satisfaction_score"] >= 4).cast(pl.Int64).to_numpy().astype(float)
    logit = (
        1.0 * z("satisfaction_score")
        + 0.9 * loyal
        + 0.8 * z("avg_order_value")
        - 0.7 * z("num_returns")
        + 0.5 * z("order_count")
        + 1.4 * (loyal * sat_high)
        + rng.normal(0.0, 1.3, size=df.height)
    )
    df = df.with_columns(
        [
            pl.col("loyalty_member").cast(pl.Int64).alias("loyalty_int"),
            pl.Series(TARGET, (logit > 2.0).astype(np.int64)),
            pl.int_range(0, df.height, dtype=pl.Int64).alias("row_id"),
        ]
    )
    return df.select(BASE_FEATURES + ["row_id", TARGET])


def _shift_slice(clean: pl.DataFrame) -> pl.DataFrame:
    """Economic-downturn shift: spend collapses, recency stretches, mood drops.

    Given to you — keep it intact so your drift outcome matches the grader.
    """
    return clean.with_columns(
        [
            (pl.col("avg_order_value") * 0.6).alias("avg_order_value"),
            (pl.col("total_revenue") * 0.6).alias("total_revenue"),
            (pl.col("days_since_last_order") * 1.5 + 60).alias("days_since_last_order"),
            (pl.col("satisfaction_score") - 1).alias("satisfaction_score"),
        ]
    )


_DTYPE_MAP = {
    pl.Int64: "int64",
    pl.Float64: "float64",
}


def _build_schema(df: pl.DataFrame) -> FeatureSchema:
    features = [
        FeatureField(
            name=col,
            dtype=_DTYPE_MAP.get(df[col].dtype, "float64"),
            nullable=False,
        )
        for col in BASE_FEATURES
    ]
    return FeatureSchema(
        name="premium_upsell_production",
        features=features,
        entity_id_column="row_id",
    )


def _fresh_sqlite_url(tag: str) -> tuple[str, Path]:
    """A fresh, unique temp SQLite file URL for this run."""
    path = Path(tempfile.gettempdir()) / f"mlfp03_{tag}_{os.getpid()}_{uuid.uuid4().hex}.db"
    return f"sqlite:///{path}", path


async def _run() -> dict:
    frame = _model_frame()
    schema = _build_schema(frame)
    reference = frame.select(BASE_FEATURES).head(REFERENCE_ROWS)
    clean = frame.select(BASE_FEATURES).tail(frame.height - REFERENCE_ROWS)
    shifted = _shift_slice(clean)

    registry_url, registry_path = _fresh_sqlite_url("registry")
    drift_url, drift_path = _fresh_sqlite_url("drift")

    registry_conn = ConnectionManager(registry_url)
    drift_conn = ConnectionManager(drift_url)
    await registry_conn.initialize()
    await drift_conn.initialize()
    try:
        # TODO 3: train LightGBM via TrainingPipeline on the registry connection.
        registry = ModelRegistry(registry_conn)
        pipeline = TrainingPipeline(feature_store=None, registry=registry)

        model_spec = ModelSpec(
            model_class="lightgbm.LGBMClassifier",
            hyperparameters={"n_estimators": 200, "random_state": SEED, "verbose": -1},
            framework="lightgbm",
        )
        eval_spec = EvalSpec(
            metrics=["accuracy", "f1", "auc"],
            split_strategy="holdout",
            test_size=0.25,
        )

        result = await pipeline.train(
            frame, schema, model_spec, eval_spec, experiment_name=MODEL_NAME
        )
        registered_version = result.model_version.version
        reference_auc = result.metrics["auc"]

        # TODO 4: promote staging -> production, then confirm.
        await registry.promote_model(
            MODEL_NAME,
            registered_version,
            "production",
            reason="Task 4: initial production rollout of premium-upsell model.",
        )
        confirmed = await registry.get_model(MODEL_NAME, stage="production")
        production_stage = confirmed.stage

        # TODO 5: arm DriftMonitor on the SEPARATE drift connection.
        monitor = DriftMonitor(
            drift_conn,
            tenant_id="_single",
            psi_threshold=PSI_THRESHOLD,
            ks_threshold=KS_THRESHOLD,
        )
        await monitor.set_reference_data(MODEL_NAME, reference, BASE_FEATURES)

        clean_report = await monitor.check_drift(MODEL_NAME, clean)
        shift_report = await monitor.check_drift(MODEL_NAME, shifted)

        n_drifted_clean = sum(
            1 for f in clean_report.feature_results if f.drift_detected
        )
        n_drifted_shift = sum(
            1 for f in shift_report.feature_results if f.drift_detected
        )

        return {
            "registered_version": registered_version,
            "production_stage": production_stage,
            "reference_auc": reference_auc,
            "clean_drift_detected": clean_report.overall_drift_detected,
            "shift_drift_detected": shift_report.overall_drift_detected,
            "n_drifted_features_clean": n_drifted_clean,
            "n_drifted_features_shift": n_drifted_shift,
            "shift_severity": shift_report.overall_severity,
        }
    finally:
        await registry_conn.close()
        await drift_conn.close()
        for p in (registry_path, drift_path):
            try:
                p.unlink(missing_ok=True)
            except OSError:
                pass


def solve() -> dict:
    """Train, register, promote to production, and run drift detection.

    Return a dict with: registered_version, production_stage, reference_auc,
    clean_drift_detected, shift_drift_detected, n_drifted_features_clean,
    n_drifted_features_shift, shift_severity.
    """
    return asyncio.run(_run())


if __name__ == "__main__":
    print(solve())
