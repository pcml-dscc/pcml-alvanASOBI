# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP01 — Assessment Task 3: Window Functions & Price Trends  (SOLVED)

    python grader.py task3.py
"""
from __future__ import annotations

import polars as pl

from shared import MLFPDataLoader

OUT_COLS = [
    "town",
    "sale_year",
    "median_price",
    "n_sales",
    "yoy_pct",
    "rolling_3yr_avg",
    "price_rank_in_year",
]  # 7 columns — confirm against problem.md.


def solve() -> pl.DataFrame:
    loader = MLFPDataLoader()
    df = loader.load("mlfp01", "hdb_resale.parquet")

    # TODO 1 + 2 — sale_year, then aggregate to one row per (town, year).
    agg = (
        df.with_columns(pl.col("month").str.slice(0, 4).cast(pl.Int64).alias("sale_year"))
        .group_by(["town", "sale_year"])
        .agg(
            pl.col("resale_price").median().alias("median_price"),
            pl.len().cast(pl.Int64).alias("n_sales"),
        )
    )

    # TODO 3 — YoY %, computed WITHIN town ordered by year (null for first year).
    prev = pl.col("median_price").shift(1).over("town", order_by="sale_year")
    agg = agg.with_columns(
        (100.0 * (pl.col("median_price") - prev) / prev).alias("yoy_pct")
    )

    # TODO 4 — 3-year trailing mean WITHIN town (min_periods=1).
    agg = agg.with_columns(
        pl.col("median_price")
        .rolling_mean(window_size=3, min_periods=1)
        .over("town", order_by="sale_year")
        .alias("rolling_3yr_avg")
    )

    # TODO 5 — rank WITHIN year, descending (1 = most expensive), method="min".
    agg = agg.with_columns(
        pl.col("median_price")
        .rank(method="min", descending=True)
        .over("sale_year")
        .cast(pl.Int64)
        .alias("price_rank_in_year")
    )

    # TODO 6 — select + sort.
    return agg.select(OUT_COLS).sort(["town", "sale_year"])


if __name__ == "__main__":
    print(solve().head())
