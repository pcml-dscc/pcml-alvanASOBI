# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP01 — Assessment Task 2: HDB Feature Engineering  (SOLVED)

    python grader.py task2.py
"""
from __future__ import annotations

import polars as pl

from shared import MLFPDataLoader

# ─────────────────────────────────────────────────────────────────────────────
#  ⚠️  VERIFY AGAINST problem.md — the room map and the 10-column order.
# ─────────────────────────────────────────────────────────────────────────────
ROOM_MAP: dict[str, int] = {
    "2 ROOM": 2, "3 ROOM": 3, "4 ROOM": 4, "5 ROOM": 5,
    "EXECUTIVE": 6,
    "MULTI-GENERATION": 7, "MULTI GENERATION": 7,
}

OUT_COLS = [
    "town",
    "flat_type",
    "sale_year",
    "storey_midpoint",
    "floor_area_sqm",
    "resale_price",
    "price_per_sqm",
    "flat_age_years",
    "flat_type_rooms",
    "remaining_lease_years",
]  # 10 columns — confirm names/order against problem.md.
# ─────────────────────────────────────────────────────────────────────────────


def solve() -> pl.DataFrame:
    loader = MLFPDataLoader()
    df = loader.load("mlfp01", "hdb_resale.parquet")

    # TODO 1 — sale_year from "YYYY-MM".
    df = df.with_columns(
        pl.col("month").str.slice(0, 4).cast(pl.Int64).alias("sale_year")
    )

    # TODO 2 — storey_midpoint. Capture the two bounds AROUND the "TO" separator
    # so the O in "TO" is never touched; fix OCR (O->0) only inside the numbers.
    lo = (pl.col("storey_range")
          .str.extract(r"(?i)([0-9O]+)\s*TO\s*[0-9O]+", 1)
          .str.replace_all("O", "0").cast(pl.Int64))
    hi = (pl.col("storey_range")
          .str.extract(r"(?i)[0-9O]+\s*TO\s*([0-9O]+)", 1)
          .str.replace_all("O", "0").cast(pl.Int64))
    df = df.with_columns(((lo + hi) / 2.0).alias("storey_midpoint"))

    # TODO 3 — flat_age_years.
    df = df.with_columns(
        (pl.col("sale_year") - pl.col("lease_commence_date").cast(pl.Int64))
        .alias("flat_age_years")
    )

    # TODO 4 — price_per_sqm.
    df = df.with_columns(
        (pl.col("resale_price") / pl.col("floor_area_sqm")).alias("price_per_sqm")
    )

    # TODO 5 — flat_type_rooms ordinal map.
    df = df.with_columns(
        pl.col("flat_type").str.strip_chars().str.to_uppercase()
        .replace_strict(ROOM_MAP, default=None)
        .cast(pl.Int64)
        .alias("flat_type_rooms")
    )

    # TODO 6 — remaining_lease_years: parse "X years Y months" OR bare "X";
    # impute nulls with the statutory 99y lease minus current flat age.
    yr = pl.col("remaining_lease").str.extract(r"(\d+)\s*year", 1).cast(pl.Float64)
    mo = pl.col("remaining_lease").str.extract(r"(\d+)\s*month", 1).cast(pl.Float64)
    bare = (pl.col("remaining_lease").str.strip_chars()
            .str.extract(r"^(\d+(?:\.\d+)?)$", 1).cast(pl.Float64))
    remaining = (
        pl.when(yr.is_not_null())
        .then(yr + mo.fill_null(0.0) / 12.0)
        .otherwise(bare)
    )
    df = df.with_columns(
        remaining.fill_null(99 - pl.col("flat_age_years"))
        .alias("remaining_lease_years")
    )

    # TODO 7 — select + sort.
    return df.select(OUT_COLS).sort(["sale_year", "town"])


if __name__ == "__main__":
    print(solve().head())
