# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP01 — Assessment Task 1: Taxi Trip Data Forensics  (SOLVED)

    python grader.py task1.py
"""
from __future__ import annotations

import polars as pl

from shared import MLFPDataLoader

# ─────────────────────────────────────────────────────────────────────────────
#  ⚠️  VERIFY THESE AGAINST problem.md — they are the only "guessed" bits.
#  The parsing / dedup / imputation logic below is exact; these constants are
#  the spec-specific values I could not see (the 15 spellings, the bounds,
#  the airport zones, and the 16-column order).
# ─────────────────────────────────────────────────────────────────────────────
DT_FMT = "%Y-%m-%d %H:%M:%S"

# 15 raw spellings -> 4 canonical labels. Keyed on lower-cased, stripped text.
PAYMENT_MAP: dict[str, str] = {
    "card": "Card", "credit": "Card", "credit card": "Card",
    "creditcard": "Card", "cc": "Card", "debit": "Card", "visa": "Card",
    "cash": "Cash", "cash payment": "Cash", "csh": "Cash",
    "nets": "NETS", "nets flashpay": "NETS",
    "grab": "Grab", "grabpay": "Grab", "grab pay": "Grab",
}

# Physical-plausibility bounds (inclusive upper, exclusive-zero lower).
MIN_FARE, MAX_FARE = 0.0, 500.0          # SGD
MIN_DIST, MAX_DIST = 0.0, 100.0          # km
MIN_PAX, MAX_PAX = 1, 6                   # passengers
MIN_DUR, MAX_DUR = 0.0, 240.0            # minutes
MIN_SPEED, MAX_SPEED = 0.0, 120.0        # km/h implied

AIRPORT_ZONES = {"Changi Airport", "Airport", "Seletar Airport"}

# Exact output order — confirm column names/order in problem.md.
OUT_COLS = [
    "trip_id",
    "pickup_datetime",
    "dropoff_datetime",
    "pickup_zone",
    "dropoff_zone",
    "passengers",
    "distance_km",
    "fare_sgd",
    "tip_sgd",
    "payment_type",
    "trip_duration_min",
    "implied_speed_kmh",
    "fare_per_km",
    "is_airport",
]  # ← this is 14; problem.md lists 16. Add the 2 missing names here.
# ─────────────────────────────────────────────────────────────────────────────


def solve() -> pl.DataFrame:
    loader = MLFPDataLoader()
    df = loader.load("mlfp01", "sg_taxi_trips.parquet")

    # TODO 1 — parse the two timestamps.
    df = df.with_columns(
        pl.col("pickup_datetime").str.to_datetime(format=DT_FMT),
        pl.col("dropoff_datetime").str.to_datetime(format=DT_FMT),
    )

    # TODO 2 — normalise payment_type (15 spellings -> 4 labels).
    df = df.with_columns(
        pl.col("payment_type")
        .str.strip_chars()
        .str.to_lowercase()
        .replace_strict(PAYMENT_MAP, default=None)
        .alias("payment_type")
    )

    # TODO 3 — impute nulls.
    df = df.with_columns(
        pl.col("tip_sgd").fill_null(0.0),
        pl.col("pickup_zone").fill_null("Unknown"),
        pl.col("dropoff_zone").fill_null("Unknown"),
    )

    # TODO 4 — derived: duration (min) then implied speed (km/h).
    df = df.with_columns(
        ((pl.col("dropoff_datetime") - pl.col("pickup_datetime"))
         .dt.total_seconds() / 60.0).alias("trip_duration_min")
    ).with_columns(
        pl.when(pl.col("trip_duration_min") > 0)
        .then(pl.col("distance_km") / (pl.col("trip_duration_min") / 60.0))
        .otherwise(None)
        .alias("implied_speed_kmh")
    )

    # TODO 5 — drop physically impossible rows (null in any bound ⇒ dropped).
    df = df.filter(
        (pl.col("fare_sgd") > MIN_FARE) & (pl.col("fare_sgd") <= MAX_FARE)
        & (pl.col("distance_km") > MIN_DIST) & (pl.col("distance_km") <= MAX_DIST)
        & (pl.col("passengers") >= MIN_PAX) & (pl.col("passengers") <= MAX_PAX)
        & (pl.col("trip_duration_min") > MIN_DUR) & (pl.col("trip_duration_min") <= MAX_DUR)
        & (pl.col("implied_speed_kmh") > MIN_SPEED) & (pl.col("implied_speed_kmh") <= MAX_SPEED)
    )

    # TODO 6 — dedup by trip_id, keep highest-fare row.
    df = (
        df.sort("fare_sgd", descending=True)
        .unique(subset="trip_id", keep="first", maintain_order=True)
    )

    # TODO 7 — derived: fare_per_km, is_airport.
    df = df.with_columns(
        (pl.col("fare_sgd") / pl.col("distance_km")).alias("fare_per_km"),
        (pl.col("pickup_zone").is_in(AIRPORT_ZONES)
         | pl.col("dropoff_zone").is_in(AIRPORT_ZONES)).alias("is_airport"),
    )

    # TODO 8 — select + sort.
    return df.select(OUT_COLS).sort("pickup_datetime")


if __name__ == "__main__":
    print(solve().head())
