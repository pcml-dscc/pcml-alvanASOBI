# Copyright 2026 Terrene Foundation
# SPDX-License-Identifier: Apache-2.0
"""
MLFP01 — Assessment Task 4: Profile, Clean & Integrate with DataExplorer  (SOLVED)

    python grader.py task4.py
"""
from __future__ import annotations

import asyncio

import polars as pl

from kailash_ml import DataExplorer
from shared import MLFPDataLoader

# ─────────────────────────────────────────────────────────────────────────────
#  ⚠️  VERIFY AGAINST problem.md — the exact 8-column output schema.
#  Known from the TODOs: period_year, period_quarter, tourist_arrivals,
#  inflation_rate, trade_balance_sgd_bn. The remaining columns (e.g. a GDP /
#  unemployment / period_type field) are whatever problem.md lists — fill them in.
# ─────────────────────────────────────────────────────────────────────────────
OUT_COLS = [
    "period_year",
    "period_quarter",
    "tourist_arrivals",
    "inflation_rate",
    "trade_balance_sgd_bn",
    # ── add the other 3 columns named in problem.md, e.g.: ──
    # "gdp_growth_pct",
    # "unemployment_rate",
    # "gdp_sgd_bn",
]
# ─────────────────────────────────────────────────────────────────────────────


def _clean(quarterly: pl.DataFrame) -> pl.DataFrame:
    # TODO 2 — parse period into year + quarter across THREE formats:
    #   "Q1 2000"   -> Q before year
    #   "2001-Q1"   -> year, then "Q" + digit
    #   "2001-2"    -> year, then bare digit
    year = pl.col("period").str.extract(r"(\d{4})", 1).cast(pl.Int64)
    q_from_q = pl.col("period").str.extract(r"[Qq](\d)", 1)        # "Q1 2000", "2001-Q1"
    q_from_dash = pl.col("period").str.extract(r"\d{4}-(\d)", 1)   # "2001-2"
    quarter = pl.coalesce([q_from_q, q_from_dash]).cast(pl.Int64)

    df = quarterly.with_columns(
        year.alias("period_year"),
        quarter.alias("period_quarter"),
        # TODO 3 — comma-stripped integer cast.
        pl.col("tourist_arrivals").cast(pl.Utf8)
        .str.replace_all(",", "")
        .str.strip_chars()
        .cast(pl.Int64, strict=False)
        .alias("tourist_arrivals"),
    )

    # TODO 4 — median-impute the two numeric indicators (median ignores nulls).
    df = df.with_columns(
        pl.col("inflation_rate").fill_null(pl.col("inflation_rate").median()),
        pl.col("trade_balance_sgd_bn").fill_null(pl.col("trade_balance_sgd_bn").median()),
    )

    # TODO 5 — select + sort.
    return df.select(OUT_COLS).sort(["period_year", "period_quarter"])


async def _alert_counts(raw_q: pl.DataFrame, cleaned: pl.DataFrame) -> tuple[int, int]:
    explorer = DataExplorer()
    raw_profile = await explorer.profile(raw_q)
    clean_profile = await explorer.profile(cleaned)
    return len(raw_profile.alerts), len(clean_profile.alerts)


def solve() -> dict:
    raw = MLFPDataLoader().load("mlfp01", "economic_indicators.csv")

    # TODO 1 — keep only the quarterly slice (used both as the "raw" baseline
    # for profiling and as the input to cleaning).
    quarterly_raw = raw.filter(pl.col("period_type") == "quarterly")

    cleaned = _clean(quarterly_raw)

    # TODO 6 — profile both frames; cleaning must REDUCE the alert count.
    raw_alert_count, clean_alert_count = asyncio.run(
        _alert_counts(quarterly_raw, cleaned)
    )

    return {
        "cleaned": cleaned,
        "raw_alert_count": raw_alert_count,
        "clean_alert_count": clean_alert_count,
    }


if __name__ == "__main__":
    result = solve()
    print(result["cleaned"].head())
    print("raw alerts:", result["raw_alert_count"],
          "| clean alerts:", result["clean_alert_count"])
